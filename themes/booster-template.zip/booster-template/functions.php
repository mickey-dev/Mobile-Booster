<?php require_once('includes/init.php'); require_once('functions_custom.php');
/*
 * Do not touch this file.
 * If you want to add any functionality you can use functions_custom.php file!
 */
