<ul>
    <?php
        dynamic_sidebar( 'primary-sidebar' );
    ?>
</ul>