<?php get_header(); ?>

<div class="container default-padding">
    <div class="row">
      <h1 class="text-center">Not Found</h1>
    </div>
</div>

<?php get_footer(); ?>
